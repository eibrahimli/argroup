/*
inspiration from:

http://pepsized.com/diagonal-thumbnails-gallery/

and David Walsh's CSS Flip animation:

https://codepen.io/darkwing/pen/bCali
