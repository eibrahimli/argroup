/**************************************************************************
 * Slider Revolution jQuery Visual Editor Extension
 * @version: 5.4.7.2 (08.03.2018)
 * @author ThemePunch
**************************************************************************/

This is the extension file for the Visual Editor Add On of Slider Revolution.

The visual-editor-extension.zip will only work in cooperation with the Slider Revolution jQuery Visual Editor Product which is available in our Portfolio at http://codecanyon.net/item/slider-revolution-jquery-visual-editor-addon/13934907 

Your Team @ThemePunch
